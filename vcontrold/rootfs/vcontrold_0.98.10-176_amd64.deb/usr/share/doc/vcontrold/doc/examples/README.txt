***********************************************************
Aktuelle Informationen und Dokus finden sich im Wiki:
https://github.com/openv/openv/wiki
***********************************************************
Die Software wird unter der GPL veroeffentlicht.
***********************************************************

Die Beispiel Scripte veranschaulichen das Loggen von Betriebsdaten in eine RRD.
