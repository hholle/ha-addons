#/bin/sh
# RDD Update V200KW2
# solarix@pingos.de
#
/root/vitotools/vclient -h 192.168.1.153:3002 -f /root/vitotools/rrd.min.cmds -t /root/vitotools/rrd.tmpl -x /root/vitotools/rrd.sh
exit
